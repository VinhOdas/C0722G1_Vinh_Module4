package com.ss7.service.category;

import com.ss7.model.Category;
import com.ss7.service.IGeneralService;

public interface ICategoryService extends IGeneralService<Category> {
}
